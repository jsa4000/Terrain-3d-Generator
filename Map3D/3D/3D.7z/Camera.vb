﻿Imports OpenTK

Public Class Camera
    Public Position As Vector3 = Vector3.Zero
    Public Orientation As New Vector3(CSng(Math.PI), 0F, 0F)
    Public MoveSpeed As Single = 0.2F
    Public MouseSensitivity As Single = 0.01F

    Public Sub New()
    End Sub

    Public Sub New(Position As Vector3, Orientation As Vector3)
        Me.Position = Position
        Me.Orientation = Orientation
    End Sub

    Public Function GetViewMatrix() As Matrix4
        Dim lookat As New Vector3()

        lookat.X = CSng(Math.Sin(CSng(Orientation.X)) * Math.Cos(CSng(Orientation.Y)))
        lookat.Y = CSng(Math.Sin(CSng(Orientation.Y)))
        lookat.Z = CSng(Math.Cos(CSng(Orientation.X)) * Math.Cos(CSng(Orientation.Y)))

        Return Matrix4.LookAt(Position, Position + lookat, Vector3.UnitY)
    End Function

    Public Sub Move(x As Single, y As Single, z As Single)
        Dim offset As New Vector3()

        Dim forward As New Vector3(CSng(Math.Sin(CSng(Orientation.X))), 0, CSng(Math.Cos(CSng(Orientation.X))))
        Dim right As New Vector3(-forward.Z, 0, forward.X)

        offset += x * right
        offset += y * forward
        offset.Y += z

        offset.NormalizeFast()
        offset = Vector3.Multiply(offset, MoveSpeed)

        Position += offset
    End Sub

    Public Sub AddRotation(x As Single, y As Single)
        x = x * MouseSensitivity
        y = y * MouseSensitivity

        Orientation.X = (Orientation.X + x) Mod (CSng(Math.PI) * 2.0F)
        Orientation.Y = Math.Max(Math.Min(Orientation.Y + y, CSng(Math.PI) / 2.0F - 0.1F), CSng(-Math.PI) / 2.0F + 0.1F)
    End Sub

End Class
