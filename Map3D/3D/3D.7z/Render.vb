﻿Imports OpenTK
Imports OpenTK.Graphics.OpenGL
Public Class Render

    ' Install Open TK dependences from Nugets command line
    '    - Install-Package OpenTK
    '    - Install-Package OpenTK.GLControl
    ' Samples
    ' https://gist.github.com/GeirGrusom/347f30e981f33972c934
    'http://neokabuto.blogspot.com.es/2014/01/opentk-tutorial-5-basic-camera.html

    ' Vertex info to render
    Private vertdata As Vector3()
    Private coldata As Vector3()
    Private texcoorddata As Vector2()
    Private normdata As Vector3()
    Private indicedata As Integer()

    Private WindowHeight As Integer = 800
    Private WindowWidth As Integer = 600

    'Current scene that is rendered
    Private CurrentScene As New Scene()
    Public View As Matrix4 = Matrix4.Identity

    Private time As Single = 0F

    Public Sub New()

    End Sub

    Public Sub SetScene(Scene As Scene)
        ' Set and load current scene
        CurrentScene = Scene
        CurrentScene.Load()
    End Sub

    Public Function GetVersion() As String
        Return GL.GetString(StringName.Vendor) & " " & GL.GetString(StringName.Renderer) & " " & GL.GetString(StringName.Version)
    End Function

    Public Sub Init(Width As Integer, Height As Integer)
        ' Enable the OpenGL Control
        GL.ClearColor(Color.Black)
        GL.Enable(EnableCap.DepthTest)
        GL.PointSize(5.0F)
        ' Forze to update the first time the render view
        ResizeWindow(Width, Height)
    End Sub

    Public Sub ResizeWindow(Width As Integer, Height As Integer)
        Me.WindowWidth = Width
        Me.WindowHeight = Height
        GL.Viewport(0, 0, Width, Height)
        Dim aspect_ratio As Single = Width / CSng(Height)
        Dim perpective As Matrix4 = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspect_ratio, 1, 64)
        GL.MatrixMode(MatrixMode.Projection)
        GL.LoadMatrix(perpective)
    End Sub

    Public Sub RenderFrame()
        GL.Viewport(0, 0, WindowWidth, WindowHeight)
        GL.Clear(ClearBufferMask.ColorBufferBit Or ClearBufferMask.DepthBufferBit)
        GL.Enable(EnableCap.DepthTest)

        'Get the current Active shader loaded
        Dim ActiveShader As ShaderProgram = CurrentScene.Shaders(CurrentScene.ActiveShader)

        GL.UseProgram(ActiveShader.ProgramID)
        ActiveShader.EnableVertexAttribArrays()

        Dim indiceat As Integer = 0

        ' Draw all objects
        For Each v As Volume In CurrentScene.Objects
            GL.BindTexture(TextureTarget.Texture2D, v.TextureID)
            GL.UniformMatrix4(ActiveShader.GetUniform("modelview"), False, v.ModelViewProjectionMatrix)

            If ActiveShader.GetAttribute("maintexture") <> -1 Then
                GL.Uniform1(ActiveShader.GetAttribute("maintexture"), v.TextureID)
            End If

            If ActiveShader.GetUniform("view") <> -1 Then
                GL.UniformMatrix4(CurrentScene.Shaders(CurrentScene.ActiveShader).GetUniform("view"), False, View)
            End If

            If ActiveShader.GetUniform("model") <> -1 Then
                GL.UniformMatrix4(ActiveShader.GetUniform("model"), False, v.ModelMatrix)
            End If

            If ActiveShader.GetUniform("material_ambient") <> -1 Then
                'GL.Uniform3(ActiveShader.GetUniform("material_ambient"), v.Material.AmbientColor)
                '  GL.Uniform3(v.Material.AmbientColor, ActiveShader.GetUniform("material_ambient"))
            End If

            If ActiveShader.GetUniform("material_diffuse") <> -1 Then
                'GL.Uniform3(ActiveShader.GetUniform("material_diffuse"), v.Material.DiffuseColor)
                '  GL.Uniform3(v.Material.DiffuseColor, ActiveShader.GetUniform("material_diffuse"))
            End If

            If ActiveShader.GetUniform("material_specular") <> -1 Then
                'GL.Uniform3(ActiveShader.GetUniform("material_specular"), v.Material.SpecularColor)
                ' GL.Uniform3(v.Material.SpecularColor, ActiveShader.GetUniform("material_specular"))
            End If

            If ActiveShader.GetUniform("material_specExponent") <> -1 Then
                GL.Uniform1(ActiveShader.GetUniform("material_specExponent"), v.Material.SpecularExponent)
            End If

            If ActiveShader.GetUniform("light_position") <> -1 Then
                'GL.Uniform3(ActiveShader.GetUniform("light_position"), CurrentScene.ActiveLight.Position)
                ' GL.Uniform3(CurrentScene.ActiveLight.Position, ActiveShader.GetUniform("light_position"))
            End If

            If ActiveShader.GetUniform("light_color") <> -1 Then
                'GL.Uniform3(ActiveShader.GetUniform("light_color"), CurrentScene.ActiveLight.Color)
                ' GL.Uniform3(CurrentScene.ActiveLight.Color, ActiveShader.GetUniform("light_color"))
            End If

            If ActiveShader.GetUniform("light_diffuseIntensity") <> -1 Then
                GL.Uniform1(ActiveShader.GetUniform("light_diffuseIntensity"), CurrentScene.ActiveLight.DiffuseIntensity)
            End If

            If ActiveShader.GetUniform("light_ambientIntensity") <> -1 Then
                GL.Uniform1(ActiveShader.GetUniform("light_ambientIntensity"), CurrentScene.ActiveLight.AmbientIntensity)
            End If

            GL.DrawElements(BeginMode.Triangles, v.IndiceCount, DrawElementsType.UnsignedInt, indiceat * 4)
            indiceat += v.IndiceCount
        Next
        ActiveShader.DisableVertexAttribArrays()

        GL.Flush()
    End Sub

    Public Sub UpdateFrame()

        Dim verts As New List(Of Vector3)()
        Dim inds As New List(Of Integer)()
        Dim colors As New List(Of Vector3)()
        Dim texcoords As New List(Of Vector2)()
        Dim normals As New List(Of Vector3)()

        ' Assemble vertex and indice data for all volumes
        Dim vertcount As Integer = 0
        For Each v As Volume In CurrentScene.Objects
            verts.AddRange(v.GetVertices().ToList())
            inds.AddRange(v.GetIndices(vertcount).ToList())
            colors.AddRange(v.GetColorData().ToList())
            texcoords.AddRange(v.GetTextureCoords())
            normals.AddRange(v.GetNormals().ToList())
            vertcount += v.VerticeCount
        Next

        vertdata = verts.ToArray()
        indicedata = inds.ToArray()
        coldata = colors.ToArray()
        texcoorddata = texcoords.ToArray()
        normdata = normals.ToArray()

        ''Get the current Active shader loaded
        Dim ActiveShader As ShaderProgram = CurrentScene.Shaders(CurrentScene.ActiveShader)
        GL.BindBuffer(BufferTarget.ArrayBuffer, ActiveShader.GetBuffer("vPosition"))

        GL.BufferData(Of Vector3)(BufferTarget.ArrayBuffer, New System.IntPtr(vertdata.Length * Vector3.SizeInBytes), vertdata, BufferUsageHint.StaticDraw)
        GL.VertexAttribPointer(ActiveShader.GetAttribute("vPosition"), 3, VertexAttribPointerType.Float, False, 0, 0)

        ' Buffer vertex color if shader supports it
        If ActiveShader.GetAttribute("vColor") <> -1 Then
            GL.BindBuffer(BufferTarget.ArrayBuffer, ActiveShader.GetBuffer("vColor"))
            GL.BufferData(Of Vector3)(BufferTarget.ArrayBuffer, New System.IntPtr(coldata.Length * Vector3.SizeInBytes), coldata, BufferUsageHint.StaticDraw)
            GL.VertexAttribPointer(ActiveShader.GetAttribute("vColor"), 3, VertexAttribPointerType.Float, True, 0, 0)
        End If

        ' Buffer texture coordinates if shader supports it
        If ActiveShader.GetAttribute("texcoord") <> -1 Then
            GL.BindBuffer(BufferTarget.ArrayBuffer, ActiveShader.GetBuffer("texcoord"))
            GL.BufferData(Of Vector2)(BufferTarget.ArrayBuffer, New System.IntPtr(texcoorddata.Length * Vector2.SizeInBytes), texcoorddata, BufferUsageHint.StaticDraw)
            GL.VertexAttribPointer(ActiveShader.GetAttribute("texcoord"), 2, VertexAttribPointerType.Float, True, 0, 0)
        End If

        If ActiveShader.GetAttribute("vNormal") <> -1 Then
            GL.BindBuffer(BufferTarget.ArrayBuffer, ActiveShader.GetBuffer("vNormal"))
            GL.BufferData(Of Vector3)(BufferTarget.ArrayBuffer, New System.IntPtr(normdata.Length * Vector3.SizeInBytes), normdata, BufferUsageHint.StaticDraw)
            GL.VertexAttribPointer(ActiveShader.GetAttribute("vNormal"), 3, VertexAttribPointerType.Float, True, 0, 0)
        End If

        ' Update object positions
        time += CSng(2)

        CurrentScene.Objects(0).Position = New Vector3(0.3F, -0.5F + CSng(Math.Sin(time)), -3.0F)
        CurrentScene.Objects(0).Rotation = New Vector3(0.55F * time, 0.25F * time, 0)
        CurrentScene.Objects(0).Scale = New Vector3(0.5F, 0.5F, 0.5F)

        CurrentScene.Objects(1).Position = New Vector3(-1.0F, 0.5F + CSng(Math.Cos(time)), -2.0F)
        CurrentScene.Objects(1).Rotation = New Vector3(-0.25F * time, -0.35F * time, 0)
        CurrentScene.Objects(1).Scale = New Vector3(0.7F, 0.7F, 0.7F)

        ' Update model view matrices
        For Each v As Volume In CurrentScene.Objects
            v.CalculateModelMatrix()
            v.ViewProjectionMatrix = CurrentScene.Camera.GetViewMatrix() * Matrix4.CreatePerspectiveFieldOfView(1.3F, WindowWidth / CSng(WindowHeight), 1.0F, 40.0F)
            v.ModelViewProjectionMatrix = v.ModelMatrix * v.ViewProjectionMatrix
        Next

        GL.UseProgram(ActiveShader.ProgramID)

        GL.BindBuffer(BufferTarget.ArrayBuffer, 0)

        ' Buffer index data
        GL.BindBuffer(BufferTarget.ElementArrayBuffer, CurrentScene.ibo_elements)
        GL.BufferData(BufferTarget.ElementArrayBuffer, New System.IntPtr(indicedata.Length * 4), indicedata, BufferUsageHint.StaticDraw)


        ' Reset mouse position
        'If Focused Then
        '    Dim delta As Vector2 = lastMousePos - New Vector2(OpenTK.Input.Mouse.GetState().X, OpenTK.Input.Mouse.GetState().Y)
        '    lastMousePos += delta

        '    cam.AddRotation(delta.X, delta.Y)
        '    ResetCursor()
        'End If

        View = CurrentScene.Camera.GetViewMatrix()
    End Sub



End Class
