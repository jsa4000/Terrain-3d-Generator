﻿Imports System.IO
Imports OpenTK
Imports OpenTK.Graphics.OpenGL

Public Class Scene

    Public Objects As New List(Of Volume)()
    Public Camera As New Camera()
    Public ActiveLight As New Light(New Vector3(), New Vector3(0.9F, 0.8F, 0.8F))

    Public Textures As New Dictionary(Of String, Integer)()
    Public Shaders As New Dictionary(Of String, ShaderProgram)()
    Public ActiveShader As String = "normal"
    Public Materials As New Dictionary(Of String, Material)()

    ' Number of Buffers created
    Public ibo_elements As Integer 'Buffer elements

    Public Sub Load()
        GL.GenBuffers(1, ibo_elements)

        ' Load shaders from file
        shaders.Add("default", New ShaderProgram("vs.glsl", "fs.glsl", True))
        shaders.Add("textured", New ShaderProgram("vs_tex.glsl", "fs_tex.glsl", True))
        shaders.Add("normal", New ShaderProgram("vs_norm.glsl", "fs_norm.glsl", True))
        shaders.Add("lit", New ShaderProgram("vs_lit.glsl", "fs_lit.glsl", True))

        activeShader = "lit"

        'Load materials for the current scene.
        loadMaterials("opentk.mtl")

        ' Create our objects
        Dim tc As New TexturedCube()
        tc.TextureID = textures(materials("opentk1").DiffuseMap)
        tc.CalculateNormals()
        tc.Material = materials("opentk1")
        objects.Add(tc)

        Dim tc2 As New TexturedCube()
        tc2.Position += New Vector3(1.0F, 1.0F, 1.0F)
        tc2.TextureID = textures(materials("opentk2").DiffuseMap)
        tc2.CalculateNormals()
        tc2.Material = materials("opentk2")
        objects.Add(tc2)

        ' Move camera away from origin
        camera.Position += New Vector3(0F, 0F, 3.0F)

        textures.Add("earth.png", Images.LoadImage("earth.png"))
        Dim earth As ObjVolume = ObjVolume.LoadFromFile("earth.obj")
        earth.TextureID = textures("earth.png")
        earth.Position += New Vector3(1.0F, 1.0F, -2.0F)
        earth.Material = New Material(New Vector3(0.15F), New Vector3(1), New Vector3(0.2F), 5)
        objects.Add(earth)

    End Sub

    Private Sub loadMaterials(filename As String)
        For Each item In Material.LoadFromFile(filename)
            If Not materials.ContainsKey(item.Key) Then
                materials.Add(item.Key, item.Value)
            End If
        Next

        ' Load textures
        For Each mat As Material In materials.Values
            If File.Exists(mat.AmbientMap) AndAlso Not textures.ContainsKey(mat.AmbientMap) Then
                textures.Add(mat.AmbientMap, Images.LoadImage(mat.AmbientMap))
            End If

            If File.Exists(mat.DiffuseMap) AndAlso Not textures.ContainsKey(mat.DiffuseMap) Then
                textures.Add(mat.DiffuseMap, Images.LoadImage(mat.DiffuseMap))
            End If

            If File.Exists(mat.SpecularMap) AndAlso Not textures.ContainsKey(mat.SpecularMap) Then
                textures.Add(mat.SpecularMap, Images.LoadImage(mat.SpecularMap))
            End If

            If File.Exists(mat.NormalMap) AndAlso Not textures.ContainsKey(mat.NormalMap) Then
                textures.Add(mat.NormalMap, Images.LoadImage(mat.NormalMap))
            End If

            If File.Exists(mat.OpacityMap) AndAlso Not textures.ContainsKey(mat.OpacityMap) Then
                textures.Add(mat.OpacityMap, Images.LoadImage(mat.OpacityMap))
            End If
        Next
    End Sub

End Class
